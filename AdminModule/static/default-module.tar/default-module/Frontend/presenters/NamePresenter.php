<?php

namespace FrontendModule\#Name#Module;

/**
 * Description of #Name#Presenter
 *
 * @author #Author# <#AuthorEmail#>
 */
class #Name#Presenter extends \FrontendModule\BasePresenter
{
    /**
     * Assigned page.
     * @var WebCMS\Entity\Page
     */
	private $page;
	
	protected function startup() 
    {
		parent::startup();
	}

	protected function beforeRender()
    {
		parent::beforeRender();	
	}
	
	public function actionDefault($id)
    {	
		
	}
	
	public function renderDefault($id)
    {	
		$this->template->page = $this->page;
		$this->template->id = $id;
	}
}