#Name# module (#name#-module)
=========================

[![Total Downloads](https://poser.pugx.org/webcms2/#name#-module/downloads.png)](https://packagist.org/packages/webcms2/#name#-module)
[![Latest Stable Version](https://poser.pugx.org/webcms2/#name#-module/v/stable.png)](https://github.com/webcms2/#name#-module/releases)
[![Latest Unstable Version](https://poser.pugx.org/webcms2/#name#-module/v/unstable.png)](https://packagist.org/packages/webcms2/#name#-module)
[![License](https://poser.pugx.org/webcms2/#name#-module/license.png)](https://packagist.org/packages/webcms2/#name#-module)

#Description#

INSTALLATION
-----------

Add this line into your compser.json file.

```
"webcms2/#name#-module" : "0.*@dev"
```