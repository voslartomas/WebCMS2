<?php

namespace WebCMS\#Name#Module;

/**
 * Description of #name#
 *
 * @author #Author# <#AuthorEmail#>
 */
class #Name# extends \WebCMS\Module
{
	/**
	 * [$name description]
	 * @var string
	 */
    protected $name = '#Name#';
    
    /**
     * [$author description]
     * @var string
     */
    protected $author = '#Author#';
    
    /**
     * [$presenters description]
     * @var array
     */
    protected $presenters = array(
		array(
		    'name' => '#Name#',
		    'frontend' => TRUE,
		    'parameters' => FALSE
		),
		array(
		    'name' => 'Settings',
		    'frontend' => FALSE
		)
    );

    /**
     * [$params description]
     * @var array
     */
    protected $params = array();

    /**
     * [$cloneable description]
     * @var boolean
     */
    protected $cloneable = false;

    /**
     * [$translatable description]
     * @var boolean
     */
    protected $translatable = false;

    /**
     * [$searchable description]
     * @var boolean
     */
    protected $searchable = false;

    public function __construct() 
    {
	
    }
}
