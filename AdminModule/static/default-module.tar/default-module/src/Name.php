<?php

/**
 * This file is part of the #Name# module for webcms2.
 * Copyright (c) @see LICENSE
 */

namespace WebCMS\#Name#Module;

/**
 * Description of #name#
 *
 * @author #Author# <#AuthorEmail#>
 */
class #Name# extends \WebCMS\Module
{
	/**
	 * [$name description]
	 * @var string
	 */
    protected $name = '#Name#';
    
    /**
     * [$author description]
     * @var string
     */
    protected $author = '#Author#';
    
    /**
     * [$presenters description]
     * @var array
     */
    protected $presenters = array(
		array(
		    'name' => '#Name#',
		    'frontend' => TRUE,
		    'parameters' => FALSE
		),
		array(
		    'name' => 'Settings',
		    'frontend' => FALSE
		)
    );

    public function __construct() 
    {
	
    }
}
